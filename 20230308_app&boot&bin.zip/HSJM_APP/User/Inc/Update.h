#ifndef _UPDATE_H_
#define _UPDATE_H_


#include "Define.h"
#include "fmc_App.h"


typedef void (*pFunction)(void);
extern pFunction Jump_To_Bootloader;

typedef enum{
	IDLE=0, 
	READY, 
	BLANK, 
	PROGRAMMING, 
	PROGRAMMING_CHECK,
	PROGRAMMING_COMPLETED,
	WAITING_FOR_RESET
}_BootLoader_State;//������ѯBootloader״̬ö��
extern uint64_t BootLoader_State;

typedef struct{
	uint8_t RequestBootloaderAccess[7];
	uint8_t InputAccessKey1[9];
	uint8_t InputAccessKey2[9];
	uint8_t QueryBootloaderStatus[11];
	uint8_t EraseAppArea[11];
	uint8_t StartProgramming[11];
	uint8_t BootloaderReset[11];
}_Std_Receive_Arr;//��׼��������
extern const _Std_Receive_Arr Std_Receive_Arr;

typedef struct{
	uint8_t RequestBootloaderAccess[7];
	uint8_t InputAccessKey1[7];
	uint8_t InputAccessKey2[7];
	uint8_t Check_Ready[11];
	uint8_t Check_Blank[11];
	uint8_t Check_Programming[11];
	uint8_t Programming_Completed[11];
	uint8_t Line_Programming_Succeed[11];
	uint8_t Line_Programming_Failed[11];
	uint8_t Waiting_for_Reset[11];
}_Std_Replay_Arr;//��׼�ظ�����
extern const _Std_Replay_Arr Std_Replay_Arr;


typedef struct{
	uint8_t Rec_Valid_Array[50];
	uint8_t Bin_Data_Array[32];
	uint64_t Bin64_Data_Array[4];
	uint64_t AllDataSum;
	uint16_t AllDataSum_LSB;
	uint32_t LineSum;
	uint8_t LineSum_LSB;
	uint8_t EndIndex;
	uint16_t AllDataSum_LSB_in_CMD;
}_S19Fire;//�ļ���¼��У�鲿�ֵĽṹ��
extern _S19Fire S19_Fire;

typedef enum {
	Start = 0,
    RequestBootloaderAccess, // �������BootloaderȨ��
    InputAccessKey1,         // ����Access Key 1
    InputAccessKey2,         // ����Access Key 2
	Waiting_2s,
	Waiting_1s,
	Waiting_100ms,
	Waiting_200ms,
    QueryBootloaderStatus,   // ��ѯBootloader״̬
    EraseAppArea,            // ����APP����
    StartProgramming,        // ��ʼ���
	ReceiveS19,              // ����S19�ļ�
	Verify_Flash_Checksum,
	BL_Reset,
	End
}_BootloaderStatus;
extern _BootloaderStatus BootloaderStatus;


typedef enum {
    Re_Idle = 0,
    Re_Check_Ready,   
    Re_Check_Blank,
    Re_Check_Programming,
    Re_Line_Programming_Succeed,
    Re_Line_Programming_Failed,
    Re_RequestBootloaderAccess,
    Re_AccessKey1,
    Re_AccessKey2
}_UpdateReply;
extern _BootloaderStatus BootloaderStatus;

void Notice_Master_to_Read_Updating(_UpdateReply tobe_reply);
ErrStatus i2c_receive_check(uint8_t source_arr[20], uint8_t target_arr[], uint8_t *new_arr, uint8_t num);
void Update_Process(void);
void Updating(void);
bool compareArrays(uint8_t arr1[], uint8_t arr2[], uint8_t size);
static ErrStatus SaveProc(void);
void get_Rec_Valid_Array(uint8_t arr[]) ;
void get_Bin_Data_Array(uint8_t arr[]) ;
void Calculate_Sum_of_Data(uint8_t arr[], uint64_t *sum);
void Calculate_Sum_of_Line(uint8_t arr[], uint32_t *sum, uint8_t *sum_lsb) ;
void cx(void);

extern uint8_t ReadFrameChecksumBuff(uint8_t *Buff, uint8_t Length);





#endif