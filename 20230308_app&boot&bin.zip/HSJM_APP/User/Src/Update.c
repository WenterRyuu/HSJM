/*******************************************************************************
 * Project	:������ĻMCU����_BOE�ɶ�
 * MCU	  	:GD32A503KCU3
 * Data		:2023/10/23
 * Files	:Backlight.c
 * Library	:V1.1.0, firmware for GD32A50x
 * Function	:������صĺ��������̿���
 * Author	:Liu Wei
 * Phone	:13349168457
 ******************************************************************************/
 #include "Update.h"



const _Std_Receive_Arr Std_Receive_Arr = {
	.RequestBootloaderAccess = {0x5A, 0x05, 0x07, 0x02, 0x31, 0x01, 0x9A},
	.InputAccessKey1 = {0x5A, 0x05, 0x07, 0x04, 0x31, 0x03, 0xA5, 0x5A, 0x9D},
	.InputAccessKey2 = {0x5A, 0x05, 0x07, 0x04, 0x31, 0x04, 0xC3, 0x3C, 0x9E},
	.QueryBootloaderStatus = {0x5A, 0x05, 0x0B, 0x06, 0xB0, 0x01, 0x01, 0x00, 0x00, 0x00, 0x22},
	.EraseAppArea = {0x5A, 0x05, 0x0B, 0x06, 0xB0, 0x01, 0x02, 0x00, 0x00, 0x00, 0x23},
	.StartProgramming = {0x5A, 0x05, 0x0B, 0x06, 0xB0, 0x01, 0x03, 0x00, 0x00, 0x00, 0x24},
	.BootloaderReset = {0x5A, 0x05, 0x0B, 0x06, 0xB0, 0x01, 0x05, 0x00, 0x00, 0x00, 0x26},
};



const _Std_Replay_Arr Std_Replay_Arr = {
	.RequestBootloaderAccess = {0x5A, 0x06, 0x07, 0x02, 0x31, 0x01, 0x9B},
	.InputAccessKey1 = {0x5A, 0x06, 0x07, 0x02, 0x31, 0x03, 0x9D},
	.InputAccessKey2 = {0x5A, 0x06, 0x07, 0x02, 0x31, 0x04, 0x9E},
	.Check_Ready = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x02, 0x01, 0x01, 0x00, 0x00, 0x25}, //Bootloader ��ǰ���� Ready ״̬����ʾ Bootloader ����ɹ�
	.Check_Blank = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x02, 0x01, 0x02, 0x00, 0x00, 0x26},//Bootloader ��ǰ���� Blank ״̬����ʾ�����ɹ�
	.Check_Programming = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x02, 0x01, 0x03, 0x00, 0x00, 0x27}, //Bootloader ��ǰ���� Programming ״̬����ʾ������ģʽ�ɹ�
	.Line_Programming_Succeed = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x03, 0x01, 0x00, 0x00, 0x00, 0x25},//һ��д��ɹ�
	.Line_Programming_Failed = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x03, 0xFF, 0x00, 0x00, 0x00, 0x23},//һ��д��ʧ��
	.Programming_Completed = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x02, 0x01, 0x04, 0x00, 0x00, 0x28},
	.Waiting_for_Reset = {0x5A, 0x06, 0x0B, 0x06, 0xB0, 0x02, 0x01, 0x05, 0x00, 0x00, 0x29},
}; 

uint64_t *pBL_State = (uint64_t *)UPDATE_FLAG_ADDRESS;
uint64_t *pApp_Once = (uint64_t *)APP2BOOT_FLAG_ADDRESS;
tI2c_Type Update_tI2cSlave;	
uint64_t BootLoader_State = IDLE;
_BootloaderStatus BootloaderStatus = Start;
pFunction Jump_To_Bootloader;
uint32_t JumpAddress = 0;

//==============================================================================
_UpdateReply UpdateReply = Re_Idle;
void Notice_Master_to_Read_Updating(_UpdateReply tobe_reply)
{
    switch(tobe_reply)
    {
        case Re_Check_Ready:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x0B;
            tI2cSlave.Send_Buff[3] = 0x06;
            tI2cSlave.Send_Buff[4] = 0xB0;
            tI2cSlave.Send_Buff[5] = 0x02;
            tI2cSlave.Send_Buff[6] = 0x01;
            tI2cSlave.Send_Buff[7] = 0x01;
            tI2cSlave.Send_Buff[8] = 0x00;
            tI2cSlave.Send_Buff[9] = 0x00;
            tI2cSlave.Send_Buff[10] = 0x25;
            memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 11 ;
            break;
        case Re_Check_Blank:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x0B;
            tI2cSlave.Send_Buff[3] = 0x06;
            tI2cSlave.Send_Buff[4] = 0xB0;
            tI2cSlave.Send_Buff[5] = 0x02;
            tI2cSlave.Send_Buff[6] = 0x01;
            tI2cSlave.Send_Buff[7] = 0x02;
            tI2cSlave.Send_Buff[8] = 0x00;
            tI2cSlave.Send_Buff[9] = 0x00;
            tI2cSlave.Send_Buff[10] = 0x26;
            memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 11 ; 
            break;
        case Re_Check_Programming:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x0B;
            tI2cSlave.Send_Buff[3] = 0x06;
            tI2cSlave.Send_Buff[4] = 0xB0;
            tI2cSlave.Send_Buff[5] = 0x02;
            tI2cSlave.Send_Buff[6] = 0x01;
            tI2cSlave.Send_Buff[7] = 0x03;
            tI2cSlave.Send_Buff[8] = 0x00;
            tI2cSlave.Send_Buff[9] = 0x00;
            tI2cSlave.Send_Buff[10] = 0x27;
            memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 11 ;       
            break; 
        case Re_Line_Programming_Succeed:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x0B;
            tI2cSlave.Send_Buff[3] = 0x06;
            tI2cSlave.Send_Buff[4] = 0xB0;
            tI2cSlave.Send_Buff[5] = 0x03;
            tI2cSlave.Send_Buff[6] = 0x01;
            tI2cSlave.Send_Buff[7] = 0x00;
            tI2cSlave.Send_Buff[8] = 0x00;
            tI2cSlave.Send_Buff[9] = 0x00;
            tI2cSlave.Send_Buff[10] = 0x25;
            memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 11 ;         
            break;
        case Re_Line_Programming_Failed:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x0B;
            tI2cSlave.Send_Buff[3] = 0x06;
            tI2cSlave.Send_Buff[4] = 0xB0;
            tI2cSlave.Send_Buff[5] = 0x03;
            tI2cSlave.Send_Buff[6] = 0xFF;
            tI2cSlave.Send_Buff[7] = 0x00;
            tI2cSlave.Send_Buff[8] = 0x00;
            tI2cSlave.Send_Buff[9] = 0x00;
            tI2cSlave.Send_Buff[10] = 0x23;
            memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 11 ;          
            break;
        case Re_AccessKey1:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x07;
            tI2cSlave.Send_Buff[3] = 0x02;
            tI2cSlave.Send_Buff[4] = 0x31;
            tI2cSlave.Send_Buff[5] = 0x03;
            tI2cSlave.Send_Buff[6] = 0x9D;
            memset(&tI2cSlave.Send_Buff[7],0x00,8) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 7 ;            
            break;
        case Re_AccessKey2:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x07;
            tI2cSlave.Send_Buff[3] = 0x02;
            tI2cSlave.Send_Buff[4] = 0x31;
            tI2cSlave.Send_Buff[5] = 0x04;
            tI2cSlave.Send_Buff[6] = 0x9E;
            memset(&tI2cSlave.Send_Buff[7],0x00,8) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 7 ;    
            break;
        case Re_RequestBootloaderAccess:
            tI2cSlave.Send_Buff[0] = 0x5A;
            tI2cSlave.Send_Buff[1] = 0x06;
            tI2cSlave.Send_Buff[2] = 0x07;
            tI2cSlave.Send_Buff[3] = 0x02;
            tI2cSlave.Send_Buff[4] = 0x31;
            tI2cSlave.Send_Buff[5] = 0x01;
            tI2cSlave.Send_Buff[6] = 0x9B;
            memset(&tI2cSlave.Send_Buff[7],0x00,8) ;
            tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15) ;
            tI2cSlave.SendSize = 7 ;       
            break; 
        default:
            break;
    }
    IRQ_LOW_DOWN;
    //Counter_1ms.IRQ_Update = 100;     
}
//==============================================================================

/*------------------------------------------------------------------------------
*Function name		 :i2c_receive_check
*Function description:��i2c������յ������в��Ҳ�ʶ���Ƿ����Ŀ������(���ҵ���һ��ƥ�������ʼ��������ȡ11���ֽ�)
*Ipunt				 :��source_arr[]�������ض���11���ֽ�target_arr[]����(���͵�11�����ٵ���7��)����ֵ��������*new_arr
*OutPut				 :SUCCSE or ERROR
*-----------------------------------------------------------------------------*/
ErrStatus i2c_receive_check(uint8_t source_arr[20], uint8_t target_arr[], uint8_t *new_arr, uint8_t num)
{    
    for (int i = 0; i <= 20 - num; ++i)                                         //(Ŀ����11���ֽ�)�ܹ���ѭ��9�Σ��Ҳ����Ͳ������� 
	{
        int found = 1;
        for (int j = 0; j < num; ++j) 
		{
            if (source_arr[i + j] != target_arr[j])                             //0		0 //i==0˵���ǵ�һ���� 
			{										                            //0+1	1
                found = 0;							                            //0+2	2
                break;								                            //0+3	3
            }
        }

        if (found) 									                            //�ҵ��˵�һ���� 
		{
            for (int k = 0; k < num; ++k)                                       //��ֵ��������
			{
                new_arr[k] = source_arr[i + k];
            }

            for (int l = 0; l < num; ++l) 
			{
                if (new_arr[l] != target_arr[l])                                //�������Ŀ��������
				{
                    return ERROR;
                }
            }

            return SUCCESS;
        }
    }

    return ERROR;
}
/*------------------------------------------------------------------------------
*Function name		 :Notice_master_to_read
*Function description:֪ͨ��������ȡIIC�ϵ����ݣ�����ָ�룩
*Ipunt				 :��1��Ҫ���͵������ָ��
*OutPut				 :none
*-----------------------------------------------------------------------------*/
void Notice_master_to_read(uint8_t *source) 
{
    memcpy(Update_tI2cSlave.Send_Buff, source, sizeof(Std_Receive_Arr.RequestBootloaderAccess));
	Update_tI2cSlave.SendSize = 7;
	IRQ_LOOW_DOWN();//�����ж�֪ͨ��������
	Counter_1ms.IRQ_Update = 100;		
}

/*------------------------------------------------------------------------------
*Function name		 :Update_Process
*Function description:�������̴���״̬��
*Ipunt				 :none
*OutPut				 :none
*-----------------------------------------------------------------------------*/
uint8_t flag_test = 0;
void Update_Process(void)
{
    uint8_t new_arr[11];//������11��
    memset(&new_arr[0], 0x00, 11);    
	switch(BootloaderStatus)
	{
		case RequestBootloaderAccess:
			if(compareArrays(Update_tI2cSlave.RecBuff, Std_Receive_Arr.RequestBootloaderAccess, sizeof(Std_Receive_Arr.RequestBootloaderAccess)) == true)
			{
				rcu_periph_clock_disable(RCU_TIMER5);
				rcu_periph_clock_disable(RCU_TIMER6);
				Notice_Master_to_Read_Updating(Re_RequestBootloaderAccess);
				BootloaderStatus = InputAccessKey1;
			}
			break;
		case InputAccessKey1:                                                   //��������һֱ���������߲�������ʾ���п����ķ���
			if(compareArrays(Update_tI2cSlave.RecBuff, Std_Receive_Arr.InputAccessKey1, sizeof(Std_Receive_Arr.InputAccessKey1)) == true)
			{
				Notice_Master_to_Read_Updating(Re_AccessKey1);
				BootloaderStatus = InputAccessKey2;
			}
			break;
		case InputAccessKey2:
            if(compareArrays(Update_tI2cSlave.RecBuff, Std_Receive_Arr.InputAccessKey2, sizeof(Std_Receive_Arr.InputAccessKey2)) == true)
			{
				Notice_Master_to_Read_Updating(Re_AccessKey2);                
				BootloaderStatus = QueryBootloaderStatus;
				BootLoader_State = READY;
                //@20240227
                flag_test = 1;
				fmc_uint64_program(UPDATE_FLAG_ADDRESS, BootLoader_State);
				fmc_uint64_program(APP2BOOT_FLAG_ADDRESS, 1);
				rcu_periph_clock_enable(RCU_TIMER5);//READY�Ժ��������������Ͳ�ѯ����ֵ
				rcu_periph_clock_enable(RCU_TIMER6);
				break;
			}
			break;
        case EraseAppArea:
            if(compareArrays(Update_tI2cSlave.RecBuff, Std_Receive_Arr.EraseAppArea, sizeof(Std_Receive_Arr.EraseAppArea)) == true)
            {
                delay_1ms(50);
                BootLoader_State = READY;                                       //��û����������Flash��Ļ���READY
                fmc_uint64_program(UPDATE_FLAG_ADDRESS, BootLoader_State);
				fmc_uint64_program(APP2BOOT_FLAG_ADDRESS, 1);                   //������APP����BOOT��Flash���������־Ҫд1
                
                //��ת
//                rcu_deinit();                                                 //����BOOT���������ܲ���APP���������
//                gpio_deinit(GPIOA);
//                gpio_deinit(GPIOB);
//                gpio_deinit(GPIOC);
//                gpio_deinit(GPIOD);
//                gpio_deinit(GPIOE);
//                timer_deinit(TIMER1);
//                timer_deinit(TIMER5);
//                timer_deinit(TIMER6);
//                timer_deinit(TIMER19);
//                i2c_deinit(I2C0);
//                i2c_deinit(I2C1);
//                adc_deinit(ADC0);
//                spi_i2s_deinit(SPI0);
//                McuRcuDeinit();    
//                
//                JumpAddress = *(__IO uint32_t*)(BOOT_START_ADDRESS + 4);
//                Jump_To_Bootloader = (pFunction)JumpAddress;
//                __set_MSP(*(__IO uint32_t*) BOOT_START_ADDRESS);
//                Jump_To_Bootloader();		
                
                break;
            }
            else
                break;  
		default:
			break;
		
	}
    cx();
}

/*------------------------------------------------------------------------------
*Function name		 :Updating
*Function description:��������
*Ipunt				 :none
*OutPut				 :none
*-----------------------------------------------------------------------------*/
void Updating(void)
{	
    nvic_irq_disable(TIMER6_IRQn);
    nvic_irq_disable(TIMER5_DAC_IRQn);
	do
	{
		Update_Process();
	}
    while(BootLoader_State != READY);
    //while(*pBL_State != (uint64_t)READY);
	
    //while(IRQ_HIGH_level_Detection() == ERROR);
    
    delay_1ms(250);
    //��ת                                              
    gpio_deinit(GPIOA);  //c
//    gpio_deinit(GPIOB);
    gpio_deinit(GPIOC);
//    gpio_deinit(GPIOD);
    gpio_deinit(GPIOE);//cc
    timer_deinit(TIMER1);  //��ʱ��1���ܹر�
    timer_deinit(TIMER5);//c
    timer_deinit(TIMER6);//c
    timer_deinit(TIMER19);//c
    i2c_deinit(I2C0); //cc
//    i2c_deinit(I2C1);
    adc_deinit(ADC0);//c
    spi_i2s_deinit(SPI0);//c
    McuRcuDeinit();    
    
    JumpAddress = *(__IO uint32_t*)(BOOT_START_ADDRESS + 4);
    Jump_To_Bootloader = (pFunction)JumpAddress;
    __set_MSP(*(__IO uint32_t*) BOOT_START_ADDRESS);
    Jump_To_Bootloader();		

}

/*------------------------------------------------------------------------------
*Function name		 :Update_Process
*Function description:��������ѯBootLoader״̬����ʾ�����������͵�ǰ��״̬��Ϣ
*Ipunt				 :none
*OutPut				 :none
*-----------------------------------------------------------------------------*/
void cx(void)
{
    uint8_t new_arr[11];//������11��
    memset(&new_arr[0], 0x00, 11);
    //if(i2c_receive_check(Update_tI2cSlave.RecBuff, Std_Receive_Arr.QueryBootloaderStatus, new_arr, 11) == SUCCESS)
	if(compareArrays(Update_tI2cSlave.RecBuff, Std_Receive_Arr.QueryBootloaderStatus, sizeof(Std_Receive_Arr.QueryBootloaderStatus)) == true)
	{           
        nvic_irq_disable(TIMER6_IRQn);
        nvic_irq_disable(TIMER5_DAC_IRQn);             
        //BootLoader_State = READY;
		//�������״̬
		switch(BootLoader_State)//��ʲô״̬����ʲô���飬��ת����Ӧ�Ĳ���
		{
			case READY:
                if(flag_test == 1)
                {
                    Notice_Master_to_Read_Updating(Re_Check_Ready);
                    BootloaderStatus = EraseAppArea;
                }
				break;
			default:
                tI2cSlave.Send_Buff[0] = 0x5A;
                tI2cSlave.Send_Buff[1] = 0x06;
                tI2cSlave.Send_Buff[2] = 0x0B;
                tI2cSlave.Send_Buff[3] = 0x06;
                tI2cSlave.Send_Buff[4] = 0xB0;
                tI2cSlave.Send_Buff[5] = 0x02;
                tI2cSlave.Send_Buff[6] = 0x01;
                tI2cSlave.Send_Buff[7] = 0x00;
                tI2cSlave.Send_Buff[8] = 0x00;
                tI2cSlave.Send_Buff[9] = 0x00;
                tI2cSlave.Send_Buff[10] = 0x25;
                memset(&tI2cSlave.Send_Buff[11],0x00,4) ;
                tI2cSlave.Send_Buff[15] = ReadFrameChecksumBuff(&tI2cSlave.Send_Buff[0],15);
                tI2cSlave.SendSize = 11 ;
//                IRQ_RELEASE;
//                delay_1ms(1);
                IRQ_LOW_DOWN;
//                Counter_1ms.IRQ_Update = 100;         
                BootloaderStatus = RequestBootloaderAccess;
				break;
		}
        memset(Update_tI2cSlave.RecBuff,0x00,50);
	}
}


/*------------------------------------------------------------------------------
*Function name		 :compareArrays
*Function description:�Ƚ��������飨arr1[]��arr2[]����ǰ(size)��Ԫ���Ƿ���ȫ��ͬ
*Ipunt				 :none
*OutPut				 :��false�����κ�λ���ҵ��˲�ͬ��Ԫ��
                      ��true������Ԫ�ض���ͬ
*-----------------------------------------------------------------------------*/
bool compareArrays(uint8_t arr1[], uint8_t arr2[], uint8_t size) 
{
    for (int i = 0; i < size; i++) 
	{
        if (arr1[i] != arr2[i]) 
		{
            return false;
        }
    }
    return true;
}

/*------------------------------------------------------------------------------
*Function name		 :SaveProc
*Function description:�����ݴ浽APP�����棬���Ҽ��
*Ipunt				 :none
*OutPut				 :none
*-----------------------------------------------------------------------------*/
static ErrStatus SaveProc(void)
{
	//BIN�ļ���ʼ��ȫΪ0XFF
	memset(S19_Fire.Bin_Data_Array, 0xFF, sizeof(S19_Fire.Bin_Data_Array));
	//��ȡ��Data������Ļ���0xFF
	get_Bin_Data_Array(S19_Fire.Rec_Valid_Array);
	get_Bin64_Data_Array(S19_Fire.Bin_Data_Array, S19_Fire.Bin64_Data_Array);
	//���°�BIN�ļ���ʼ��ȫΪ0XFF
	memset(S19_Fire.Bin_Data_Array, 0xFF, sizeof(S19_Fire.Bin_Data_Array));
	
	static uint32_t start_address = APP_START_ADDRESS;
	fmc_program(start_address, S19_Fire.Bin64_Data_Array);
	
	bool is_check_ok = fmc_program_check(start_address, S19_Fire.Bin64_Data_Array);
	
	start_address += 0x20;
	return is_check_ok;
}

//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------

_S19Fire S19_Fire;


/*------------------------------------------------------------------------------
*Function name		 :get_Rec_Valid_Array
*Function description:��RecBuff������Ѱ�����һ������0��Ԫ�ص�λ�ã�
                      Ȼ�󽫴�RecBuff[0]����λ�õ�����Ԫ�ظ��Ƶ�Rec_Valid_Array������ 
*Ipunt				 :Update_tI2cSlave.RecBuff[]
*OutPut				 :none
*Demo                :get_Rec_Valid_Array(Update_tI2cSlave.RecBuff);
*-----------------------------------------------------------------------------*/
void get_Rec_Valid_Array(uint8_t arr[]) 
{
    // ��ʼ��EndIndex
    S19_Fire.EndIndex = 49;
    // �����һ��Ԫ����ǰ�ң��ҵ���һ������Ԫ��
    while (S19_Fire.EndIndex >= 0 && arr[S19_Fire.EndIndex] == 0) 
	{
        --S19_Fire.EndIndex;
    }
    // ����ҵ��˷���Ԫ�أ���RecBuff�а������㼰֮ǰ������Ԫ�ظ��Ƶ�Rec_Valid_Array
    if (S19_Fire.EndIndex >= 0) 
	{
		uint8_t i = 0;
        for (i = 0; i <= S19_Fire.EndIndex; ++i) 
		{
            S19_Fire.Rec_Valid_Array[i] = arr[i];
        }
    }
}


/*------------------------------------------------------------------------------
*Function name		 :get_Bin_Data_Array
*Function description:��S19_Fire.Rec_Valid_Array������Ѱ�����һ������0��Ԫ�ص�λ�ã�
                      Ȼ�󽫴ӵ�8����������2��֮�������Ԫ�ظ��Ƶ�S19_Fire.Bin_Data_Array������ 
*Ipunt				 :Update_tI2cSlave.RecBuff[]
*OutPut				 :none
*Demo                :get_Rec_Valid_Array(S19_Fire.Rec_Valid_Array);
*-----------------------------------------------------------------------------*/
void get_Bin_Data_Array(uint8_t arr[]) 
{
    // ��ʼ��EndIndex
    S19_Fire.EndIndex = 49;
    // �����һ��Ԫ����ǰ�ң��ҵ���һ������Ԫ��
    while (S19_Fire.EndIndex >= 0 && arr[S19_Fire.EndIndex] == 0) 
	{
        --S19_Fire.EndIndex;
    }
	//�ѽ��յ���S3��¼�����8�����������ڶ�����֮�������ֵ��Bin_Data_Array������Ҫд�뵽APP��������������
	for(uint8_t i = 0; i <= (S19_Fire.EndIndex-8); ++i) 
	{
		S19_Fire.Bin_Data_Array[i] = arr[i+7];
	}
}

/*------------------------------------------------------------------------------
*Function name		 :Calculate_Sum_of_Data
*Function description:����Rec_Valid_Array������ָ����Χ��Ԫ�ص��ܺ�
                      ���ӵ�8��Ԫ�ص�������2��Ԫ�أ������µ�AllDataSum���� 
*Ipunt				 :Rec_Valid_Array, �ۼӵĺ͵�ָ��
*OutPut				 :none
*Demo                :Calculate_Sum_of_Data(Rec_Valid_Array, &AllDataSum);
*-----------------------------------------------------------------------------*/
void Calculate_Sum_of_Data(uint8_t arr[], uint64_t *sum) 
{
    //*sum = 0; // ��ʼ���ܺ�
    S19_Fire.EndIndex = 49;
    // �ҵ�Rec_Valid_Array�е����һ������Ԫ��
    while(S19_Fire.EndIndex >= 0 && arr[S19_Fire.EndIndex] == 0) 
	{
        --S19_Fire.EndIndex;
    }
    // �ӵ�8��Ԫ�ؿ�ʼ����������2��Ԫ�ؽ����������ܺ�
    uint8_t i = 0;
    for (i = 7; i <= S19_Fire.EndIndex-1; ++i) 
	{
        *sum += arr[i];
    }
	//*sum_lsb = *sum & 0xFFFF;//����Data(��������¼�ļ�)��У��
}


/*------------------------------------------------------------------------------
*Function name		 :Calculate_Sum_of_Line
*Function description:�� Rec_Valid_Array �������棬�ӵ�3��Ԫ�ص�������2��Ԫ��֮���
                      ����Ԫ�أ�������β����ӣ��ѽ���洢�� LineSum ���档
*Ipunt				 :
*OutPut				 :none
*-----------------------------------------------------------------------------*/
void Calculate_Sum_of_Line(uint8_t arr[], uint32_t *sum, uint8_t *sum_lsb) 
{
    S19_Fire.EndIndex = 49;
    // �ҵ�Rec_Valid_Array�е����һ������Ԫ��
    while (S19_Fire.EndIndex >= 0 && arr[S19_Fire.EndIndex] == 0) 
	{
        --S19_Fire.EndIndex;
    }
    // �ӵ�3��Ԫ�ؿ�ʼ����������2��Ԫ�ؽ����������ܺ�
    uint8_t i = 0;
    for (i = 2; i <= S19_Fire.EndIndex-1; ++i) 
	{
        *sum += arr[i];
    }
    *sum_lsb = ~(*sum & 0xFF);//��У�������
}

