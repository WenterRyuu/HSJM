#ifndef _ADC_APP_H_
#define _ADC_APP_H_



#include "Define.h"



void adc_config(void);
void McuAdcInitialization(void);





#endif
