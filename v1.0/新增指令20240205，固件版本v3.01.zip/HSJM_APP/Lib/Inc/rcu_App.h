#ifndef _RCU_APP_H_
#define _RCU_APP_H_





#include "Define.h"
#include "gd32a50x_rcu.h"


//-----------------------------------------------------------------------------------
//��������
void McuRcuInitialization(void);
void McuRcuDeinit(void);


#endif

