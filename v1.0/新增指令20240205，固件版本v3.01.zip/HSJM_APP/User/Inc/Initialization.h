#ifndef _INITIALIZATION_H_
#define _INITIALIZATION_H_


#include "Define.h"

extern void I2c_SlaveInit(void) ;

//-----------------------------------------------------------------------------------
//��̬��������
void McuInitialization(void);
void AppInitialization(void);
void Initialization(void);


#endif
